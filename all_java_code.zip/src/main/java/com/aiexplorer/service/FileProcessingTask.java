package com.aiexplorer.service;

import javafx.concurrent.Task;
import org.json.JSONObject;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileProcessingTask extends Task<Void> {
    private final List<File> files;
    private final DatabaseService dbService;
    private static final String PYTHON_SCRIPT_PATH = "./firstrun.py";

    public FileProcessingTask(List<File> files) {
        this.files = files;
        this.dbService = DatabaseService.getInstance();
    }

    @Override
    protected Void call() throws Exception {
        // Ensure database tables exist
        dbService.ensureTablesExist();

        int totalFiles = files.size();
        for (int i = 0; i < files.size(); i++) {
            // Check if task was cancelled
            if (isCancelled()) {
                break;
            }

            File file = files.get(i);
            updateMessage("Processing: " + file.getName());
            updateProgress(i, totalFiles);

            try {
                // Run Python script for this file
                String jsonOutput = runPythonScript(file);

                // Parse JSON response
                JSONObject result = new JSONObject(jsonOutput);

                if (result.getBoolean("success")) {
                    // Extract data from JSON
                    String filename = result.getString("filename");
                    double confidence = result.getDouble("confidence");
                    String topGenre = result.getString("top_genre");
                    double topGenreScore = result.getDouble("top_genre_score");

                    // Get keywords as comma-separated string
                    JSONObject keywordsObj = result.getJSONObject("keywords");
                    StringBuilder keywords = new StringBuilder();
                    for (String key : keywordsObj.keySet()) {
                        keywords.append(key).append(", ");
                    }
                    if (keywords.length() > 0) {
                        keywords.setLength(keywords.length() - 2); // Remove trailing ", "
                    }

                    // Save to database
                    boolean saved = dbService.saveOrUpdateFileAnalysis(
                            filename,
                            keywords.toString(),
                            topGenreScore,
                            file.getAbsolutePath(),
                            confidence
                    );

                    if (saved) {
                        System.out.println("✓ Saved to database: " + filename);
                    }
                } else {
                    String error = result.getString("error");
                    System.err.println("✗ Error processing " + file.getName() + ": " + error);
                }

            } catch (Exception e) {
                System.err.println("✗ Exception processing " + file.getName() + ": " + e.getMessage());
                e.printStackTrace();
            }

            updateProgress(i + 1, totalFiles);
        }

        return null;
    }

    /**
     * Runs the Python script for a single file
     */
    private String runPythonScript(File file) throws IOException {
        // Build command: python3 firstrun.py /path/to/file.pdf
        ProcessBuilder pb = new ProcessBuilder(
                "python3",
                PYTHON_SCRIPT_PATH,
                file.getAbsolutePath()
        );

        // Set working directory to project root
        pb.directory(new File("."));

        // Start process
        Process process = pb.start();

        // Read output
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream())
        );

        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }

        // Read errors (for debugging)
        BufferedReader errorReader = new BufferedReader(
                new InputStreamReader(process.getErrorStream())
        );

        StringBuilder errors = new StringBuilder();
        while ((line = errorReader.readLine()) != null) {
            errors.append(line).append("\n");
        }

        // Wait for process to complete
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            process.destroy();
            throw new IOException("Python script interrupted", e);
        }

        // If there were errors, log them
        if (errors.length() > 0) {
            System.err.println("[PYTHON ERROR] " + errors.toString());
        }

        return output.toString().trim();
    }
}