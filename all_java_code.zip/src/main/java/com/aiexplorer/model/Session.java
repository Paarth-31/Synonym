package com.aiexplorer.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Session Model - Represents an active user session
 * Tracks user interactions, analyzed files, and session metadata
 */
public class Session {
    private int id;
    private int userId;
    private String sessionName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private List<String> analyzedFilePaths;
    private int totalFilesAnalyzed;
    private String sessionStatus; // ACTIVE, COMPLETED, PAUSED
    private String analysisResults;
    private boolean isActive;

    // Constructor 1: Default
    public Session() {
        this.analyzedFilePaths = new ArrayList<>();
        this.startTime = LocalDateTime.now();
        this.sessionStatus = "ACTIVE";
        this.isActive = true;
        this.totalFilesAnalyzed = 0;
    }

    // Constructor 2: With userId and sessionName
    public Session(int userId, String sessionName) {
        this();
        this.userId = userId;
        this.sessionName = sessionName;
    }

    // Constructor 3: Full
    public Session(int userId, String sessionName, int totalFilesAnalyzed) {
        this();
        this.userId = userId;
        this.sessionName = sessionName;
        this.totalFilesAnalyzed = totalFilesAnalyzed;
    }

    // ============================================
    // GETTERS AND SETTERS
    // ============================================

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getSessionName() {
        return sessionName;
    }

    public void setSessionName(String sessionName) {
        this.sessionName = sessionName;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public List<String> getAnalyzedFilePaths() {
        return analyzedFilePaths;
    }

    public void setAnalyzedFilePaths(List<String> analyzedFilePaths) {
        this.analyzedFilePaths = analyzedFilePaths;
    }

    public int getTotalFilesAnalyzed() {
        return totalFilesAnalyzed;
    }

    public void setTotalFilesAnalyzed(int totalFilesAnalyzed) {
        this.totalFilesAnalyzed = totalFilesAnalyzed;
    }

    public String getSessionStatus() {
        return sessionStatus;
    }

    public void setSessionStatus(String sessionStatus) {
        this.sessionStatus = sessionStatus;
    }

    public String getAnalysisResults() {
        return analysisResults;
    }

    public void setAnalysisResults(String analysisResults) {
        this.analysisResults = analysisResults;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    // ============================================
    // UTILITY METHODS
    // ============================================

    /**
     * Add file to this session
     */
    public void addAnalyzedFile(String filePath) {
        if (!this.analyzedFilePaths.contains(filePath)) {
            this.analyzedFilePaths.add(filePath);
            this.totalFilesAnalyzed++;
        }
    }

    /**
     * Remove file from session
     */
    public void removeAnalyzedFile(String filePath) {
        if (this.analyzedFilePaths.remove(filePath)) {
            this.totalFilesAnalyzed--;
        }
    }

    /**
     * Complete the session
     */
    public void completeSession() {
        this.endTime = LocalDateTime.now();
        this.sessionStatus = "COMPLETED";
        this.isActive = false;
    }

    /**
     * Pause the session
     */
    public void pauseSession() {
        this.sessionStatus = "PAUSED";
        this.isActive = false;
    }

    /**
     * Resume the session
     */
    public void resumeSession() {
        this.sessionStatus = "ACTIVE";
        this.isActive = true;
    }

    /**
     * Get session duration in seconds
     */
    public long getSessionDurationSeconds() {
        LocalDateTime end = endTime != null ? endTime : LocalDateTime.now();
        return java.time.temporal.ChronoUnit.SECONDS.between(startTime, end);
    }

    /**
     * Get session duration in minutes
     */
    public long getSessionDurationMinutes() {
        return getSessionDurationSeconds() / 60;
    }

    /**
     * Get formatted session info
     */
    public String getSessionInfo() {
        return String.format(
                "Session: %s\n" +
                        "User ID: %d\n" +
                        "Files: %d\n" +
                        "Status: %s\n" +
                        "Duration: %d minutes\n" +
                        "Started: %s",
                sessionName, userId, totalFilesAnalyzed, sessionStatus,
                getSessionDurationMinutes(), startTime
        );
    }

    /**
     * Check if session has expired (older than 24 hours)
     */
    public boolean hasExpired() {
        if (endTime == null) {
            return false;
        }
        return java.time.temporal.ChronoUnit.HOURS.between(endTime, LocalDateTime.now()) > 24;
    }

    /**
     * Clear all analyzed files from session
     */
    public void clearAnalyzedFiles() {
        analyzedFilePaths.clear();
        totalFilesAnalyzed = 0;
    }

    /**
     * Get session summary
     */
    public String getSummary() {
        return String.format(
                "%s - %d files analyzed (%s)",
                sessionName, totalFilesAnalyzed, sessionStatus
        );
    }

    @Override
    public String toString() {
        return "Session{" +
                "id=" + id +
                ", userId=" + userId +
                ", sessionName='" + sessionName + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", totalFilesAnalyzed=" + totalFilesAnalyzed +
                ", sessionStatus='" + sessionStatus + '\'' +
                ", isActive=" + isActive +
                '}';
    }
}
