package com.aiexplorer.model;

import java.time.LocalDateTime;

public class FileAnalyzedItem {
    private int id;
    private String name;
    private String keywords;
    private double genre;
    private String fileLocation;
    private double confidenceScore;
    private LocalDateTime analyzedAt;

    // Constructor
    public FileAnalyzedItem(int id, String name, String keywords, double genre,
                            String fileLocation, double confidenceScore, LocalDateTime analyzedAt) {
        this.id = id;
        this.name = name;
        this.keywords = keywords;
        this.genre = genre;
        this.fileLocation = fileLocation;
        this.confidenceScore = confidenceScore;
        this.analyzedAt = analyzedAt;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getKeywords() { return keywords; }
    public void setKeywords(String keywords) { this.keywords = keywords; }
    public double getGenre() { return genre; }
    public void setGenre(double genre) { this.genre = genre; }
    public String getFileLocation() { return fileLocation; }
    public void setFileLocation(String fileLocation) { this.fileLocation = fileLocation; }
    public double getConfidenceScore() { return confidenceScore; }
    public void setConfidenceScore(double confidenceScore) { this.confidenceScore = confidenceScore; }
    public LocalDateTime getAnalyzedAt() { return analyzedAt; }
    public void setAnalyzedAt(LocalDateTime analyzedAt) { this.analyzedAt = analyzedAt; }
}
