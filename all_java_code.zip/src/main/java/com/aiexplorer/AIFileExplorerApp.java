package com.aiexplorer;

import com.aiexplorer.service.DatabaseService;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

/**
 * Main Application Entry Point for Synonym File Explorer
 * Loads the login screen as the first view
 */
public class AIFileExplorerApp extends Application {
    // In constructor or static block
    static {
        // Initialize database when app starts
        DatabaseService.getInstance();
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            // Load login page as the first screen
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Scene scene = new Scene(loader.load(), 900, 600);

            // Load CSS
            String css = Objects.requireNonNull(
                    getClass().getResource("/styles/auth-theme.css")
            ).toExternalForm();
            scene.getStylesheets().add(css);

            // Configure stage
            primaryStage.setTitle("Synonym - Intelligent File Discovery");
            primaryStage.setScene(scene);
            primaryStage.setMinWidth(800);
            primaryStage.setMinHeight(500);
            primaryStage.centerOnScreen();

            // Show the window
            primaryStage.show();

            System.out.println("✓ Synonym application started successfully");

        } catch (IOException e) {
            System.err.println("✗ Error loading login page: " + e.getMessage());
            e.printStackTrace();
            showErrorDialog("Failed to load application", e.getMessage());
        } catch (NullPointerException e) {
            System.err.println("✗ Resource not found: " + e.getMessage());
            e.printStackTrace();
            showErrorDialog("Resource Missing", "FXML or CSS file not found. Please check resources folder.");
        }
    }

    /**
     * Show error dialog when application fails to start
     */
    private void showErrorDialog(String title, String message) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.ERROR
        );
        alert.setTitle(title);
        alert.setHeaderText("Application Error");
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Cleanup on application exit
     */
    @Override
    public void stop() {
        System.out.println("✓ Synonym application closed");
    }

    /**
     * Main method - entry point
     */
    public static void main(String[] args) {
        // Initialize database on startup
        try {
            com.aiexplorer.service.DatabaseService.getInstance();
            System.out.println("✓ Database initialized");
        } catch (Exception e) {
            System.err.println("✗ Database initialization failed: " + e.getMessage());
        }

        // Launch JavaFX application
        launch(args);
    }
}
