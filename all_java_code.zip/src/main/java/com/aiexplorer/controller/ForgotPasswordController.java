package com.aiexplorer.controller;

import com.aiexplorer.model.User;
// import com.aiexplorer.service.DatabaseService;
import com.aiexplorer.util.PasswordUtil;
import com.aiexplorer.util.ValidationUtil;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class ForgotPasswordController {

    @FXML private TextField emailField;
    @FXML private PasswordField newPasswordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Button resetButton;
    @FXML private Button backButton;
    @FXML private Label errorLabel;

    private // DatabaseService dbService = DatabaseService.getInstance();

    @FXML
    public void initialize() {
        resetButton.setOnAction(e -> handlePasswordReset());
        backButton.setOnAction(e -> switchToLogin());
    }

    @FXML
    private void handlePasswordReset() {
        errorLabel.setText("");

        // Validation
        if (!ValidationUtil.isValidEmail(emailField.getText())) {
            errorLabel.setText("✗ Please enter a valid email");
            return;
        }

        User user = // dbService.getUserByEmail(emailField.getText());
        if (user == null) {
            errorLabel.setText("✗ Email not found");
            return;
        }

        if (!PasswordUtil.isPasswordStrong(newPasswordField.getText())) {
            errorLabel.setText("✗ Password must be strong (8+ chars, uppercase, lowercase, digit, special)");
            return;
        }

        if (!newPasswordField.getText().equals(confirmPasswordField.getText())) {
            errorLabel.setText("✗ Passwords don't match");
            return;
        }

        // Update password
        if (// dbService.updatePassword(user.getId(), newPasswordField.getText())) {
            errorLabel.setText("✓ Password reset successful!");
            errorLabel.setStyle("-fx-text-fill: #107c10;");
            switchToLogin();
        } else {
            errorLabel.setText("✗ Error resetting password");
        }
    }

    @FXML
    private void switchToLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Scene scene = new Scene(loader.load(), 900, 600);
            String css = getClass().getResource("/styles/auth-theme.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Synonym - Login");
        } catch (IOException e) {
            showError("Error loading login page: " + e.getMessage());
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
