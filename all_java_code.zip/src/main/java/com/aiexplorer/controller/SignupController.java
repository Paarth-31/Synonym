package com.aiexplorer.controller;

// import com.aiexplorer.service.DatabaseService;
import com.aiexplorer.util.PasswordUtil;
import com.aiexplorer.util.ValidationUtil;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class SignupController {

    @FXML private TextField fullNameField;
    @FXML private TextField emailField;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Button signupButton;
    @FXML private Button backButton;
    @FXML private Label errorLabel;
    @FXML private ProgressBar strengthBar;
    @FXML private Label strengthLabel;

    private // DatabaseService dbService = DatabaseService.getInstance();

    @FXML
    public void initialize() {
        setupPasswordStrengthIndicator();
        backButton.setOnAction(e -> switchToLogin());
        signupButton.setOnAction(e -> handleSignup());
    }

    private void setupPasswordStrengthIndicator() {
        passwordField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal.isEmpty()) {
                strengthBar.setProgress(0);
                strengthLabel.setText("");
                return;
            }

            if (PasswordUtil.isPasswordStrong(newVal)) {
                strengthBar.setStyle("-fx-accent: #107c10;");
                strengthBar.setProgress(1.0);
                strengthLabel.setText("Strong password ✓");
                strengthLabel.setStyle("-fx-text-fill: #107c10;");
            } else if (newVal.length() >= 6) {
                strengthBar.setStyle("-fx-accent: #ff8c00;");
                strengthBar.setProgress(0.6);
                strengthLabel.setText("Weak password");
                strengthLabel.setStyle("-fx-text-fill: #ff8c00;");
            } else {
                strengthBar.setStyle("-fx-accent: #e81123;");
                strengthBar.setProgress(0.3);
                strengthLabel.setText("Very weak");
                strengthLabel.setStyle("-fx-text-fill: #e81123;");
            }
        });
    }

    @FXML
    private void handleSignup() {
        errorLabel.setText("");

        // Validation
        if (!ValidationUtil.isValidName(fullNameField.getText())) {
            errorLabel.setText("✗ Please enter a valid full name");
            return;
        }

        if (!ValidationUtil.isValidEmail(emailField.getText())) {
            errorLabel.setText("✗ Please enter a valid email");
            return;
        }

        if (!ValidationUtil.isValidUsername(usernameField.getText())) {
            errorLabel.setText("✗ Username must be 3-20 alphanumeric characters");
            return;
        }

        if (!PasswordUtil.isPasswordStrong(passwordField.getText())) {
            errorLabel.setText("✗ Password must be strong (8+ chars, uppercase, lowercase, digit, special char)");
            return;
        }

        if (!passwordField.getText().equals(confirmPasswordField.getText())) {
            errorLabel.setText("✗ Passwords don't match");
            return;
        }

        // Register user
        boolean success = // dbService.registerUser(
                usernameField.getText(),
                emailField.getText(),
                passwordField.getText(),
                fullNameField.getText()
        );

        if (success) {
            errorLabel.setText("✓ Account created successfully!");
            errorLabel.setStyle("-fx-text-fill: #107c10;");
            switchToLogin();
        } else {
            errorLabel.setText("✗ Email or username already exists");
        }
    }

    @FXML
    private void switchToLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Scene scene = new Scene(loader.load(), 900, 600);
            String css = getClass().getResource("/styles/auth-theme.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Synonym - Login");
        } catch (IOException e) {
            showError("Error loading login page: " + e.getMessage());
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
