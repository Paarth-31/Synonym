package com.aiexplorer.controller;

import com.aiexplorer.model.User;
import com.aiexplorer.service.SessionManager;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.time.format.DateTimeFormatter;

public class ProfileController {

    @FXML private Label fullNameLabel;
    @FXML private Label emailLabel;
    @FXML private Label usernameLabel;
    @FXML private Label joinDateLabel;

    private SessionManager sessionManager = SessionManager.getInstance();

    @FXML
    public void initialize() {
        User user = sessionManager.getCurrentUser();
        if (user != null) {
            fullNameLabel.setText(user.getFullName());
            emailLabel.setText(user.getEmail());
            usernameLabel.setText(user.getUsername());

            if (user.getCreatedAt() != null) {
                String date = user.getCreatedAt().format(DateTimeFormatter.ofPattern("MMM dd, yyyy"));
                joinDateLabel.setText(date);
            }
        }
    }

    @FXML
    private void closeProfile() {
        Stage stage = (Stage) fullNameLabel.getScene().getWindow();
        stage.close();
    }
}
