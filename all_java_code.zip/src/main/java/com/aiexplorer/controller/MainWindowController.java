package com.aiexplorer.controller;

import javafx.animation.FadeTransition;
import javafx.beans.property.SimpleStringProperty;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.prefs.Preferences;
import java.util.stream.Collectors;
import com.aiexplorer.service.FileProcessingTask;

public class MainWindowController {

    @FXML private BorderPane mainBorderPane;
    @FXML private TreeView<String> folderTreeView;
    @FXML private TableView<FileItem> fileTableView;
    @FXML private TableColumn<FileItem, String> nameColumn;
    @FXML private TableColumn<FileItem, String> genreColumn;
    @FXML private TableColumn<FileItem, String> dateColumn;
    @FXML private TextField searchBar;
    @FXML private Label currentPathLabel;
    @FXML private Label statusLabel;
    @FXML private Label selectionLabel;
    @FXML private Button backButton;
    @FXML private Button forwardButton;
    @FXML private Button upButton;
    @FXML private Button refreshButton;
    @FXML private Button newFolderButton;
    @FXML private Button homeButton;
    @FXML private Button profileButton;
    @FXML private Button addFilesButton;
    @FXML private Button analyzeButton;
    @FXML private ProgressBar progressBar;
    @FXML private VBox emptyStatePanel;
    @FXML private VBox analysisResultsPanel;

    private File currentDirectory;
    private List<File> navigationHistory = new ArrayList<>();
    private List<FileItem> allAnalyzedFiles = new ArrayList<>();
    private int historyIndex = -1;
    private ExecutorService executorService = Executors.newSingleThreadExecutor();
    private Task<?> currentAnalysisTask = null;
    private static final List<String> ALL_GENRES = Arrays.asList(
        "fiction", "non-fiction", "fantasy", "science-fiction", "mystery", "thriller",
        "romance", "horror", "documents", "images", "videos", "audio", "code", "archives", "other"
    );

    @FXML
    public void initialize() {
        setupFileTable();
        setupTreeView();
        setupSearchBar();
        setupToolbar();
        loadBookmarks();
        navigateToHome();
        updateStatusBar();
        showEmptyState();
    }

    private void setupFileTable() {
        nameColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().name));
        genreColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().genre));
        dateColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().date));
        
        fileTableView.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) {
                FileItem selected = fileTableView.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    File file = new File(selected.fullPath);
                    if (selected.isDirectory) navigateToDirectory(file);
                    else openFile(file);
                }
            }
        });
        
        FadeTransition fadeIn = new FadeTransition(Duration.millis(400), fileTableView);
        fadeIn.setFromValue(0.5);
        fadeIn.setToValue(1);
        fadeIn.play();
    }

    private void setupTreeView() {
        TreeItem<String> root = new TreeItem<>("💻 This PC");
        root.setExpanded(true);
        String userHome = System.getProperty("user.home");
        addTreeItem(root, "🏠 Home", new File(userHome));
        addTreeItem(root, "🖥️ Desktop", new File(userHome, "Desktop"));
        addTreeItem(root, "📥 Downloads", new File(userHome, "Downloads"));
        folderTreeView.setRoot(root);
        folderTreeView.setShowRoot(true);
    }

    private void addTreeItem(TreeItem<String> parent, String name, File path) {
        TreeItem<String> item = new TreeItem<>(name);
        parent.getChildren().add(item);
    }

    private void loadBookmarks() { }

    private void setupSearchBar() {
        if (searchBar != null) {
            searchBar.setPromptText("🔍 Search files...");
        }
    }

    private void setupToolbar() {
        if (backButton != null) backButton.setOnAction(e -> navigateBack());
        if (forwardButton != null) forwardButton.setOnAction(e -> navigateForward());
        if (upButton != null) upButton.setOnAction(e -> navigateUp());
        if (refreshButton != null) refreshButton.setOnAction(e -> refreshCurrentDirectory());
        if (newFolderButton != null) newFolderButton.setOnAction(e -> createNewFolder());
        if (homeButton != null) homeButton.setOnAction(e -> handleHomeButton());
        if (profileButton != null) profileButton.setOnAction(e -> handleProfileButton());
        if (addFilesButton != null) addFilesButton.setOnAction(e -> addFilesForAnalysis());
        if (analyzeButton != null) analyzeButton.setOnAction(e -> handleAnalyzeButtonClick());
    }

    @FXML
    private void handleAnalyzeButtonClick() {
        List<File> selectedFiles = getSelectedFiles();
        
        if (selectedFiles.isEmpty()) {
            showAlert("No Files Selected", "Please select files to analyze", Alert.AlertType.WARNING);
            return;
        }

        analyzeButton.setDisable(true);
        statusLabel.setText("📊 Starting analysis...");

        FileProcessingTask task = new FileProcessingTask(selectedFiles);

        if (progressBar != null) {
            progressBar.progressProperty().bind(task.progressProperty());
        }
        statusLabel.textProperty().bind(task.messageProperty());

        task.setOnSucceeded(event -> {
            analyzeButton.setDisable(false);
            statusLabel.setText("✓ Analysis complete!");
            loadAnalyzedFilesFromDatabase();
            if (progressBar != null) {
                progressBar.progressProperty().unbind();
            }
        });

        task.setOnFailed(event -> {
            analyzeButton.setDisable(false);
            statusLabel.setText("✗ Analysis failed");
            showAlert("Analysis Error", task.getException().getMessage(), Alert.AlertType.ERROR);
            if (progressBar != null) {
                progressBar.progressProperty().unbind();
            }
        });

        currentAnalysisTask = task;
        executorService.execute(task);
    }

    private List<File> getSelectedFiles() {
        List<FileItem> items = fileTableView.getItems();
        List<File> files = new ArrayList<>();
        for (FileItem item : items) {
            files.add(new File(item.fullPath));
        }
        return files;
    }

    private void loadAnalyzedFilesFromDatabase() {
        allAnalyzedFiles.clear();
        allAnalyzedFiles.addAll(fileTableView.getItems());
        updateFileTable();
        statusLabel.setText("📂 " + allAnalyzedFiles.size() + " files analyzed");
    }

    private void updateFileTable() {
        fileTableView.getItems().setAll(allAnalyzedFiles);
    }

    private void addFilesForAnalysis() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Files for Analysis");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("All Files", "*.*"),
            new FileChooser.ExtensionFilter("PDF Documents", "*.pdf")
        );
        
        List<File> files = fileChooser.showOpenMultipleDialog(addFilesButton.getScene().getWindow());
        if (files != null && !files.isEmpty()) {
            for (File file : files) {
                FileItem item = new FileItem(file.getName(), "Pending", formatDate(file.lastModified()),
                    file.getAbsolutePath(), false);
                if (!allAnalyzedFiles.contains(item)) {
                    allAnalyzedFiles.add(item);
                }
            }
            updateFileTable();
            statusLabel.setText("Added " + files.size() + " file(s)");
        }
    }

    private void handleHomeButton() { }
    private void handleProfileButton() { }
    
    private void navigateToHome() {
        navigateToDirectory(new File(System.getProperty("user.home")));
    }

    private void navigateToDirectory(File directory) {
        if (directory == null || !directory.exists() || !directory.isDirectory()) return;
        currentDirectory = directory;
        currentPathLabel.setText(directory.getAbsolutePath());
        loadFilesIntoTable(directory);
        updateStatusBar();
    }

    private void navigateBack() {
        if (historyIndex > 0) {
            historyIndex--;
            navigateToDirectory(navigationHistory.get(historyIndex));
        }
    }

    private void navigateForward() {
        if (historyIndex < navigationHistory.size() - 1) {
            historyIndex++;
            navigateToDirectory(navigationHistory.get(historyIndex));
        }
    }

    private void navigateUp() {
        if (currentDirectory != null) {
            File parent = currentDirectory.getParentFile();
            if (parent != null) navigateToDirectory(parent);
        }
    }

    private void refreshCurrentDirectory() {
        if (currentDirectory != null) {
            loadFilesIntoTable(currentDirectory);
            updateStatusBar();
        }
    }

    private void loadFilesIntoTable(File directory) {
        List<FileItem> items = loadFilesFromDirectory(directory);
        fileTableView.getItems().setAll(items);
    }

    private List<FileItem> loadFilesFromDirectory(File directory) {
        List<FileItem> items = new ArrayList<>();
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                try {
                    String name = file.getName();
                    String genre = file.isDirectory() ? "Folder" : "File";
                    String date = formatDate(file.lastModified());
                    items.add(new FileItem(name, genre, date, file.getAbsolutePath(), file.isDirectory()));
                } catch (Exception ignored) {}
            }
        }
        return items;
    }

    private String formatDate(long timestamp) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a");
        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault());
        return formatter.format(dateTime);
    }

    private void createNewFolder() {
        TextInputDialog dialog = new TextInputDialog("New Folder");
        dialog.setTitle("Create Folder");
        dialog.setHeaderText("Enter name:");
        dialog.showAndWait().ifPresent(name -> {
            if (currentDirectory != null && !name.trim().isEmpty()) {
                File newFolder = new File(currentDirectory, name);
                if (newFolder.mkdir()) {
                    refreshCurrentDirectory();
                    showAlert("Success", "Folder created!", Alert.AlertType.INFORMATION);
                }
            }
        });
    }

    private void openFile(File file) {
        try {
            java.awt.Desktop.getDesktop().open(file);
        } catch (IOException e) {
            showAlert("Error", "Cannot open file", Alert.AlertType.ERROR);
        }
    }

    private void updateStatusBar() {
        if (statusLabel != null && currentDirectory != null) {
            File[] files = currentDirectory.listFiles();
            statusLabel.setText("📂 " + (files != null ? files.length : 0) + " items");
        }
    }

    private void showEmptyState() {
        if (emptyStatePanel != null) {
            emptyStatePanel.setVisible(true);
            emptyStatePanel.setManaged(true);
        }
        if (analysisResultsPanel != null) {
            analysisResultsPanel.setVisible(false);
            analysisResultsPanel.setManaged(false);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class FileItem {
        public String name, genre, date, fullPath;
        public boolean isDirectory;

        public FileItem(String name, String genre, String date, String fullPath, boolean isDirectory) {
            this.name = name;
            this.genre = genre;
            this.date = date;
            this.fullPath = fullPath;
            this.isDirectory = isDirectory;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            FileItem fileItem = (FileItem) o;
            return Objects.equals(fullPath, fileItem.fullPath);
        }

        @Override
        public int hashCode() {
            return Objects.hash(fullPath);
        }
    }
}
