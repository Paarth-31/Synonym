package com.aiexplorer.controller;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

import com.aiexplorer.model.ChatHistory;
import com.aiexplorer.model.User;
// import com.aiexplorer.service.DatabaseService;
import com.aiexplorer.service.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class DashboardController {

    @FXML private Label welcomeLabel;
    @FXML private Button profileButton;
    @FXML private Button getStartedButton;
    @FXML private Button logoutButton;
    @FXML private ListView<String> chatHistoryList;
    @FXML private Label chatCountLabel;
    @FXML private Label sessionCountLabel;
    @FXML private TextArea chatDetailsArea;

    private // DatabaseService dbService = DatabaseService.getInstance();
    private SessionManager sessionManager = SessionManager.getInstance();
    private User currentUser;

    @FXML
    public void initialize() {
        currentUser = sessionManager.getCurrentUser();
        if (currentUser != null) {
            setupUI();
            loadChatHistory();
        } else {
            showError("Session expired. Please login again.");
            switchToLogin();
        }
    }

    private void setupUI() {
        welcomeLabel.setText("Welcome, " + currentUser.getFullName() + "! 👋");
        profileButton.setOnAction(e -> openProfile());
        getStartedButton.setOnAction(e -> switchToFileExplorer());
        logoutButton.setOnAction(e -> handleLogout());
        chatHistoryList.setOnMouseClicked(e -> displayChatDetails());
    }

    private void loadChatHistory() {
        List<ChatHistory> history = // dbService.getUserChatHistory(currentUser.getId());
        chatCountLabel.setText(String.valueOf(history.size()));

        if (sessionCountLabel != null) {
            sessionCountLabel.setText(String.valueOf(history.size()));
        }

        for (ChatHistory chat : history) {
            chatHistoryList.getItems().add(
                    "📋 " + chat.getSessionTitle() + " (" + chat.getFileCount() + " files)"
            );
        }

        if (history.isEmpty()) {
            chatDetailsArea.setText(
                    "No chat history yet.\n\n" +
                            "Click 'New Analysis' to begin analyzing files!"
            );
        }
        // Load analyzed files and display count
        // DatabaseService dbService = DatabaseService.getInstance();
        List<DatabaseService.FileAnalysisRecord> analyzedFiles = dbService.getAllAnalyzedFiles();

        if (sessionCountLabel != null) {
            sessionCountLabel.setText("Analyzed: " + analyzedFiles.size() + " files");
        }
    }

    private void displayChatDetails() {
        int selected = chatHistoryList.getSelectionModel().getSelectedIndex();
        if (selected >= 0) {
            String item = chatHistoryList.getItems().get(selected);
            chatDetailsArea.setText(
                    "Session: " + item + "\n\n" +
                            "Created: Nov 5, 2025\n" +
                            "Status: Completed ✓\n\n" +
                            "Click 'New Analysis' to load this session or create a new analysis."
            );
        }
    }

    @FXML
    private void switchToFileExplorer() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/main-window.fxml"));
            Scene scene = new Scene(loader.load(), 1200, 800);
            scene.getStylesheets().add(getClass().getResource("/styles/dark-professional-theme.css").toExternalForm());

            Stage stage = (Stage) getStartedButton.getScene().getWindow();
            stage.setWidth(1200);
            stage.setHeight(800);
            stage.setMinWidth(1000);
            stage.setMinHeight(600);
            stage.setScene(scene);
            stage.setTitle("Synonym - File Explorer");
            stage.centerOnScreen();

        } catch (Exception e) {
            System.err.println("❌ ERROR: " + e.getMessage());
            e.printStackTrace();
            showAlert("Error", "Failed to load File Explorer: " + e.getMessage());
        }
    }

    @FXML
    private void openProfile() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/profile.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);
            String css = getClass().getResource("/styles/auth-theme.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = new Stage();
            stage.setScene(scene);
            stage.setTitle("Synonym - Profile");
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
            showError("Error loading profile: " + e.getMessage());
        }
    }

    private void switchToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/dashboard.fxml"));
            Scene scene = new Scene(loader.load(), 1200, 800);
            scene.getStylesheets().add(getClass().getResource("/styles/auth-theme.css").toExternalForm());

            Stage stage = (Stage) getStartedButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Synonym - Dashboard");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    @FXML
    private void handleLogout() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Logout");
        confirm.setHeaderText("Are you sure?");
        confirm.setContentText("You will be logged out from Synonym.");

        if (confirm.showAndWait().get() == ButtonType.OK) {
            sessionManager.logout();
            switchToLogin();
        }
    }

    private void switchToLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Scene scene = new Scene(loader.load(), 900, 600);
            String css = getClass().getResource("/styles/auth-theme.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.setWidth(900);
            stage.setHeight(600);
            stage.setMinWidth(900);
            stage.setMinHeight(600);
            stage.setMaxWidth(900);
            stage.setMaxHeight(600);
            stage.setScene(scene);
            stage.setTitle("Synonym - Login");
            stage.centerOnScreen();
        } catch (IOException e) {
            showError("Error loading login page: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
