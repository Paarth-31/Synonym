package com.aiexplorer.controller;

import com.aiexplorer.model.User;
// import com.aiexplorer.service.DatabaseService;
import com.aiexplorer.service.SessionManager;
import com.aiexplorer.util.ValidationUtil;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    @FXML private Button signupButton;
    @FXML private Button forgotPasswordButton;
    @FXML private Label errorLabel;
    @FXML private CheckBox rememberMe;
    @FXML private ProgressBar loadingBar;

    private // DatabaseService dbService = DatabaseService.getInstance();
    private SessionManager sessionManager = SessionManager.getInstance();

    @FXML
    public void initialize() {
        setupButtonHandlers();
        setupFieldValidation();
    }

    private void setupButtonHandlers() {
        loginButton.setOnAction(e -> handleLogin());
        signupButton.setOnAction(e -> switchToSignup());
        forgotPasswordButton.setOnAction(e -> switchToForgotPassword());

        passwordField.setOnKeyPressed(e -> {
            if (e.getCode().toString().equals("ENTER")) {
                handleLogin();
            }
        });
    }

    private void setupFieldValidation() {
        usernameField.setStyle("-fx-control-inner-background: #0a0a0a; -fx-text-fill: #ffffff;");
        passwordField.setStyle("-fx-control-inner-background: #0a0a0a; -fx-text-fill: #ffffff;");
    }

    @FXML
    private void handleLogin() {
        errorLabel.setText("");
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (!ValidationUtil.isNotEmpty(username)) {
            setError("✗ Please enter your username");
            return;
        }

        if (!ValidationUtil.isNotEmpty(password)) {
            setError("✗ Please enter your password");
            return;
        }

        loadingBar.setVisible(true);
        loginButton.setDisable(true);

        User user = // dbService.loginUser(username, password);
        loadingBar.setVisible(false);
        loginButton.setDisable(false);

        if (user != null) {
            sessionManager.login(user);
            setSuccess("✓ Login successful!");
            switchToDashboard();
        } else {
            setError("✗ Invalid username or password");
            passwordField.clear();
        }
    }

    @FXML
    private void switchToSignup() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/signup.fxml"));
            Scene scene = new Scene(loader.load(), 900, 600);
            String css = getClass().getResource("/styles/auth-theme.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = (Stage) signupButton.getScene().getWindow();
            stage.setWidth(900);
            stage.setHeight(600);
            stage.setMinWidth(900);
            stage.setMinHeight(600);
            stage.setMaxWidth(900);
            stage.setMaxHeight(600);
            stage.setScene(scene);
            stage.setTitle("Synonym - Create Account");
        } catch (IOException e) {
            showError("Error loading signup page: " + e.getMessage());
        }
    }

    @FXML
    private void switchToForgotPassword() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/forgot-password.fxml"));
            Scene scene = new Scene(loader.load(), 900, 600);
            String css = getClass().getResource("/styles/auth-theme.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = (Stage) forgotPasswordButton.getScene().getWindow();
            stage.setWidth(900);
            stage.setHeight(600);
            stage.setMinWidth(900);
            stage.setMinHeight(600);
            stage.setMaxWidth(900);
            stage.setMaxHeight(600);
            stage.setScene(scene);
            stage.setTitle("Synonym - Reset Password");
        } catch (IOException e) {
            showError("Error loading forgot password page: " + e.getMessage());
        }
    }

    private void switchToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/dashboard.fxml"));
            Scene scene = new Scene(loader.load(), 1200, 800);
            String css = getClass().getResource("/styles/auth-theme.css").toExternalForm();
            scene.getStylesheets().add(css);

            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setWidth(1200);
            stage.setHeight(800);
            stage.setMinWidth(900);
            stage.setMinHeight(700);
            stage.setMaxWidth(Double.MAX_VALUE);
            stage.setMaxHeight(Double.MAX_VALUE);
            stage.setScene(scene);
            stage.setTitle("Synonym - Dashboard");
            stage.centerOnScreen();
        } catch (IOException e) {
            showError("Error loading dashboard: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void setError(String message) {
        errorLabel.setText(message);
        errorLabel.setStyle("-fx-text-fill: #e81123;");
    }

    private void setSuccess(String message) {
        errorLabel.setText(message);
        errorLabel.setStyle("-fx-text-fill: #107c10;");
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("An Error Occurred");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
